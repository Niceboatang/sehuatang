module.exports = {
    baseUrl: 'http://superupup.top',
    // baseUrl: 'http://127.0.0.1:3000'
}